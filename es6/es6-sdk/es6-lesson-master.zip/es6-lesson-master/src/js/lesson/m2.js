export default () => {
  console.log(2)
}
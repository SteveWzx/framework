export default () => {
  console.log(3)
}
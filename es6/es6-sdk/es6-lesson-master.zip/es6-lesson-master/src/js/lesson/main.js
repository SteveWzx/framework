import m1 from './m1'
import m2 from './m2'
import m3 from './m3'
m1()
m2()
m3()

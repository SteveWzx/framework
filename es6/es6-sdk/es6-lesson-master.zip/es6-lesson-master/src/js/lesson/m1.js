export default () => {
  console.log(1)
}
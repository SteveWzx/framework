export { regMobile } from './mobile/init'
export { regInfo } from './info/init'
export { regPayment } from './payment/init'

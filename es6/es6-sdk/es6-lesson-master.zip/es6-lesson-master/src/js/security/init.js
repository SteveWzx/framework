import '../common/polyfill'
import render from './render'

const security = (opts) => {
  render(opts)
}

export { security }

// import  page  from "./page";
import './base.css';
console.log('app1');
// page();
// export default function app(params) {
//     console.log('app');
// }

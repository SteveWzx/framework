export default function () {
    console.log('this is page difer');
}

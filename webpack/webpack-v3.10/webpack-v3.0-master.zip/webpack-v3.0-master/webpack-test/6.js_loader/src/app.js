// import  page  from "./page";
import './app.scss';
console.log('app1');
// page();
// export default function app(params) {
//     console.log('app');
// }

const name = 'dongw';
console.log(name);

import './base.css';
import './app.scss';
export default function () {
    console.log('this is page difer');
}

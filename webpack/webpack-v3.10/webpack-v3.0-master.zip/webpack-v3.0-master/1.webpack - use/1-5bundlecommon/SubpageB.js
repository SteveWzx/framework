import './moduleA';
export default 'SubpageB';

import './moduleA';
export default 'SubpageA';
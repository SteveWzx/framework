export default 'moduleA';


import './SubpageA';
import './SubpageB';

export default 'pageA';
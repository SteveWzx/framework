webpackJsonp([0],{

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_RESULT__;// amd
!(__WEBPACK_AMD_DEFINE_RESULT__ = (function () {
    return function (a,b) {
        return a * b;
    }
}).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ })

});
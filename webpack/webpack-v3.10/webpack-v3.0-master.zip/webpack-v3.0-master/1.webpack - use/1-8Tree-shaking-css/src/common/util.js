/**
 * Created by dongyuanjie.wudi on 2018/3/20.
 */
export function a() {
    return 'this is a'
}
export function b() {
    return 'this is b'
}
export function c() {
    return 'this is c'
}
export function d() {
    return 'this is d'
}
export function e() {
    return 'this is e'
}

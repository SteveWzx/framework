import base from './css/base.scss';
import common from './css/common.scss';

var app = document.getElementById('app');
app.innerHTML = '<div class="'+base.box+'"></div>'

import './SubpageA';
import './SubpageB';
// import * as _ from 'lodash';

export default 'pageB';
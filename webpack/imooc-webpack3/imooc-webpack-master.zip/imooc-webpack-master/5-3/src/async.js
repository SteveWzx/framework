export default {
    name: 'async'
}
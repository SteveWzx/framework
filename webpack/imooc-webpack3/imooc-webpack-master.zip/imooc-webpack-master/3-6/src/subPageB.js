import './moduleA'

console.log('this is subpageB')
export default 'subPageB'
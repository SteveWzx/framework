export const ADDTODO = 'ADDTODO'
export const DELTODO = 'DELTODO'

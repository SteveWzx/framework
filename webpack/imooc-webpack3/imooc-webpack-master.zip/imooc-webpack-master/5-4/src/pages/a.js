import react from 'react'
import moduleA from '../components/module'
import '../css/a.css'

console.log('i am a')
console.log(moduleA)
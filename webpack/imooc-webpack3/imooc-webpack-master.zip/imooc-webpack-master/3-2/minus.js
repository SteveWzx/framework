// COMMONJS

module.exports = function(a, b) {
    return a - b
}
import './moduleA'

export default 'subPageA'
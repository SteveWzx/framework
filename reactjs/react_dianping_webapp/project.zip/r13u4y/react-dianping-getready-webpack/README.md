# react-simple-o2o-demo

搭建 webpack + React 开发环境，详情参考[这里](./docs/README.md)
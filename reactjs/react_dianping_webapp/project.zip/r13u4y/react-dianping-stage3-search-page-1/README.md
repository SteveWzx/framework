# react-simple-o2o-demo

搜索页面，文档参见[这里](./docs/README.md)
/*
* @Author: Rosen
* @Date:   2017-05-17 11:26:25
* @Last Modified by:   Rosen
* @Last Modified time: 2017-05-17 11:26:46
*/

'use strict';
require('./index.css');